// const area = function (rect: { h: number, w?: number }) {
//     rect.w = rect.w || rect.h;
//     return rect.h * rect.w;
// }

// let s1 = { h: 20, w: 10 };
// console.log(area(s1));

// let s2 = { h: 20 };
// console.log(area(s2));

// let s3 = { h: 20, w: 10, d: 40 };
// console.log(area(s3));

// ----------------------------------------------------- With Interface
// interface Rectangle {
//     h: number;
//     w?: number;
// }

// const area = function (rect: Rectangle) {
//     rect.w = rect.w || rect.h;
//     return rect.h * rect.w;
// }

// let s1: Rectangle = { h: 20, w: 10 };
// console.log(area(s1));

// let s2: Rectangle = { h: 20 };        
// console.log(area(s2));

// let s3: Rectangle = { h: 20, w: 10, d: 40 };        // Error
// console.log(area(s3));

// ----------------------------------------------------- Interface with Methods
// interface IPerson {
//     name: string;
//     age: number;
//     greet: (message: string) => string;
// }

// let p1: IPerson = {
//     name: "Abhijeet",
//     age: 38,
//     greet: function (m) {
//         return "Hello";
//     }
// };

// let p2: IPerson = {
//     name: "Ramakant",
//     age: 39,
//     greet: function (m) {
//         return "Hola";
//     }
// };

// console.log(p1.greet("Hi"));
// console.log(p2.greet("Hi"));

// ----------------------------------------------------- Interface Declaration Merging
// interface IShape {
//     height: number;
// }

// interface IShape {
//     height: number;
//     width: number;
// }

// let s1: IShape = { height: 10, width: 20 };
// console.log(s1);