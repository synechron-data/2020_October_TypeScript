"use strict";
var Program = (function () {
    function Program() {
    }
    Program.main = function (arg) {
        console.log("Hello,", arg);
    };
    Program.check = function () {
        console.log("Check Called");
    };
    return Program;
}());
Program.main("Synechron");
Program.check();
//# sourceMappingURL=1_FirstDemo.js.map