"use strict";
function Check() {
    if (true) {
        var data = 10;
    }
    return data;
}
console.log(Check());
//# sourceMappingURL=3_Scopes.js.map