// Variables created are typesafe

// Implicitly Typed
// var data = 10;
// data = "ABC";       // Error

// var s = "ABC";
// s = 10;             // Error

// Untyped Variable - No Type Safety, No Intellisense
// var data;
// data = "ABC";
// data = 10;

// Explicitly Typed
// var age: number;
// age = 10;

// var city: string;
// city = "Pune";

// function add(x: number, y: number): number {
//     return x + y;
// }

// function add(x: any, y: any) {
//     return x + y;
// }

// console.log(add(2, 3));
// console.log(add(2, "ABC"));
// console.log(add("ABC", "XYZ"));

// var p = new Promise((resolve, reject) => { });
// var s: symbol = Symbol("Hello");

// number / string / boolean / undefined / Array / Object / Date / RegExp / Function / void
// Based on lib section configured in tsconfig.json

// any / never / Tuple / Interface / Enum / Class (TypeScript Keywords)