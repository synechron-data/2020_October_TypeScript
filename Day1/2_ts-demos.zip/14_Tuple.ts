// // Tuple - Stores a fixed collection of values of same or varied types, maintaining the sequence

// // var arr: number[] = [10, 20, 30, 40, 50];

// // TypeGuard Array
// // var arr: (string | number)[] = ["Manish", 1];
// // arr = ["Abhijeet", "Pune"];
// // arr = ["Abhijeet", "Pune", 2, 45];
// // arr = [2, 45];
// // arr = [1, "Abhijeet"];

// // Tuple
// let dataRow: [number, string] = [1, "Manish"];
// // dataRow = ["Abhijeet", "Pune"];
// // dataRow = [2, 45];
// // dataRow = ["Manish", 1];
// // dataRow = [1, "Abhijeet", 23];

// // console.log(dataRow[0]);
// // console.log(dataRow[1]);

// for (const data of dataRow) {
//     console.log(data);
// }

function insert(data: [number, string]) {

}

// insert([1, "ABC"]);
// insert(["ABC"]);
// insert(["ABC", 1]);