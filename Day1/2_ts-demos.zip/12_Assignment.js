"use strict";
function Reverse(strOrArr) {
    if (typeof strOrArr == "string")
        return strOrArr.split("").reverse();
    else
        return strOrArr.slice().reverse();
}
console.log(Reverse("Manish"));
console.log(Reverse(["PQR", "XYZ", "ABC"]));
//# sourceMappingURL=12_Assignment.js.map