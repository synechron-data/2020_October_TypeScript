// function Reverse(word: string): string[];
// function Reverse(words: string[]): string[];

// // function Reverse(strOrArr: any) {
// //     if (typeof strOrArr == "string")
// //         return strOrArr.split("").reverse();
// //     else
// //         return strOrArr.slice().reverse();
// // }

// function Reverse(strOrArr: any) {
//     if (typeof strOrArr == "string")
//         return strOrArr.split("").reverse();
//     else
//         return (<string[]>strOrArr).slice().reverse();
// }

// console.log(Reverse("Manish"));                 // [ 'h', 's', 'i', 'n', 'a', 'M' ]
// console.log(Reverse(["PQR", "XYZ", "ABC"]));    // [ 'ABC', 'XYZ', 'PQR' ]
// // console.log(Reverse(10));                       // Error

// ---------------------------------------------------- TypeGuards (Union Type)

// var p: number | string | boolean;
// p = 10;
// p = "ABC";
// p = true;

function Reverse(word: string): string[];
function Reverse(words: string[]): string[];

function Reverse(strOrArr: string | string[]) {
    if (typeof strOrArr == "string")
        return strOrArr.split("").reverse();
    else
        return strOrArr.slice().reverse();
}

console.log(Reverse("Manish"));                 // [ 'h', 's', 'i', 'n', 'a', 'M' ]
console.log(Reverse(["PQR", "XYZ", "ABC"]));    // [ 'ABC', 'XYZ', 'PQR' ]
