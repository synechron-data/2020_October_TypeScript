"use strict";
var data1 = "Hello, I am here";
var a1 = data1.length;
console.log(a1);
var a2 = data1.length;
console.log(a2);
var a3 = data1.length;
console.log(a3);
//# sourceMappingURL=5_TypeAssertion.js.map