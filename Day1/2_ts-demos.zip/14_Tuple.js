"use strict";
function insert(data) {
}
//# sourceMappingURL=14_Tuple.js.map