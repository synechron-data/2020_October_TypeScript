class Program {
    static main(arg: string):void{
        console.log("Hello,", arg);
    }

    static check(){
        console.log("Check Called");
    }
}

// Calling Static Methods
Program.main("Synechron");
Program.check();