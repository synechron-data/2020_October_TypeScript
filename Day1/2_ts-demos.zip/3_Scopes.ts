// // Global Scope
// // Local (Function) Scope
// // Blocked Scope (using let and const)

// // var i = 10;
// // var i = 20;
// // console.log(i);

// // Hoisting
// // i = 10;
// // console.log(i);
// // var i;

// var i = 100;
// console.log("Before, i is", i);

// // for (var i = 0; i < 5; i++) {
// //     console.log("Inside, i is", i);
// // }

// (function () {
//     for (var i = 0; i < 5; i++) {
//         console.log("Inside, i is", i);
//     }
// })();

// console.log("After, i is", i);

// -----------------------------------------------------------------------------

// let i = 10;
// let i = 20;     // Error: Cannot redeclare block-scoped variable 'i'
// console.log(i);

// Hoisting not supported
// i = 10;
// console.log(i);
// let i;

// var i = 100;
// console.log("Before, i is", i);

// for (let i = 0; i < 5; i++) {
//     console.log("Inside, i is", i);
// }

// console.log("After, i is", i);


function Check() {
    if (true) {
        var data = 10;
    }

    return data;
}


// function Check() {
//     let data;
    
//     if (true) {
//         data = 10;
//     }

//     return data;
// }

console.log(Check());